package com.example.library.utils.glide;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * @author : Alex
 * @version : V 2.0.0
 * @date : 2018/06/01
 */

@GlideModule
public class GlideModel extends AppGlideModule {
}

package com.example.administrator.wanandroid.bean

/**
 * @author : Alex
 * @version : V 2.0.0
 * @date : 2018/10/19
 */
class Bean {


    /**
     * data : null
     * errorCode : 0
     * errorMsg :
     */

    var data: Any? = null
    var errorCode: Int = 0
    var errorMsg: String? = null
}

package com.example.administrator.wanandroid

import android.app.Dialog
import android.os.Bundle
import android.support.v4.app.DialogFragment

/**
 * @author  : Alex
 * @date    : 2018/10/18
 * @version : V 2.0.0
 */
class Dialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {



        return super.onCreateDialog(savedInstanceState)
    }
}